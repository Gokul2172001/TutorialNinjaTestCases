package com.crm.qa.pages;

import com.crm.qa.base.TestBase;

public class SoftwaresPage extends TestBase {

	
}
